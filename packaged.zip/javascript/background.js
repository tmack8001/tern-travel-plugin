// background.js
chrome.runtime.onInstalled.addListener(() => {
    console.log('Extension installed!');
 });