// content.js
document.addEventListener('DOMContentLoaded', () => {
    // Select the main element with data-controller attribute
    const mainElement = document.querySelector('[data-controller="trips--index--list--kanban"]');
    if (mainElement) {
        // Find all divs that match the trip status ID pattern
        const tripStatusDivs = mainElement.querySelectorAll('div[id^="trip_status_"]');
        tripStatusDivs.forEach(div => {
            // Find the first <ul> child within each trip_status div
            const ul = div.querySelector('ul');
            if (ul) {
                // Count only direct <li> children of this <ul>
                const liCount = Array.from(ul.children).filter(child => child.tagName === 'LI').length;
                // For demonstration purposes, log or display the count
                console.log(`Trip Status ID: ${div.id}, Number of Top-Level Items: ${liCount}`);
                // Optionally add an indication in your UI:
                const messageDiv = document.createElement('div');
                messageDiv.innerText = `Trip Status ID: ${div.id} has ${liCount} top-level items.`;
                messageDiv.style.marginTop = '10px';
                div.appendChild(messageDiv);  // Append message below each Trip Status section
            } else {
                console.log(`No <ul> found in Trip Status ID: ${div.id}`);
            }
        });
    } else {
        console.error("Main element not found.");
    }
});

document.addEventListener('DOMContentLoaded', () => {
    // Select the turbo-frame containing tasks_list
    const tasksListFrame = document.getElementById('tasks_list');
    if (tasksListFrame) {
        // Extract column headers from the table header
        const columnHeadersDiv = tasksListFrame.querySelector('.table-header-group');
        const headers = Array.from(columnHeadersDiv.querySelectorAll('.table-cell'))
            .map(cell => cell.innerText.trim());
        // Prepare an array for task data
        const tasksData = [];
        // Find all rows within 'table-row-group'
        const rows = tasksListFrame.querySelectorAll('.table-row-group .table-row');
        rows.forEach(row => {
            const rowData = {};
            const cells = row.querySelectorAll('.table-cell');
            cells.forEach((cell, index) => {
                rowData[headers[index]] = cell.innerText.trim();
            });
            if (Object.keys(rowData).length > 0) {
                tasksData.push(rowData);
            }
        });
        // Convert to JSON format
        console.log(JSON.stringify(tasksData, null, 2));

        // Initialize counters for due dates
        let countDueIn7Days = 0;
        let countDueIn7To14Days = 0;
        let countDueIn14To30Days = 0;
        let countBeyond30Days = 0;

        const todayDateObj = new Date();
        function getDaysUntilDate(dueDateString) {
            const oneDay = 1000 * 60 * 60 * 24; // mills * seconds * minutes * hours
            const dueDateObj = new Date(dueDateString);
            return Math.ceil((dueDateObj - todayDateObj) / (oneDay));
        }
        tasksData.forEach(task => {
            if (task['Due Date']) {   // Assuming "Due Date" is one of your keys in JSON structure.
                const diffDays = getDaysUntilDate(task['Due Date']);
                if (diffDays <= 7 && diffDays >= 1) {
                    countDueIn7Days++;
                } else if (diffDays > 7 && diffDays <= 14) {
                    countDueIn7To14Days++;
                } else if (diffDays > 14 && diffDays <= 30) {
                    countDueIn14To30Days++;
                } else if (diffDays > 30) {
                    countBeyond30Days++;
                }
            }
        });
        console.log(`Number of Tasks Due In Next Up To & Including:`);
        console.log(`- Within Next <b>7 Days</b>: ${countDueIn7Days}`);
        console.log(`- Between <b>8 Days</b> To <b>14 Days</b>: ${countDueIn7To14Days}`);
        console.log(`- Between <b>15 Days</b> To <b>30 Days</b>: ${countDueIn14To30Days}`);
        console.log(`- Beyond <b>30 Days</b>: ${countBeyond30Days}`);

    } else {
        console.error("Tasks list frame not found.");
    }
});